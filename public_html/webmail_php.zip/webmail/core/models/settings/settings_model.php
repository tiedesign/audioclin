<?php

require_once(WM_ROOTPATH.'core/base/base_model.php');

class SettingsModel extends BaseModel
{
	
}