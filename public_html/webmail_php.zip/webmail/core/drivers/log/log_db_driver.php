<?php
class LogDbDriver
{}
