/*
 * Classes:
 *  CContactsScreen()
 */
 
function CContactsScreen()
{
	this.id = SCREEN_CONTACTS;
	this.isBuilded = false;
	this.bodyAutoOverflow = true;
	this.contacts = null;
	this.Contact = null;
	this.groups = null;
	this._groupsOutOfDate = true;
	this._groupsDeleted = false;
	this.HistoryArgs = null;
	
	this._mainDiv = null;
	this._leftDiv = null;
	this._searchByFirstCharPane = null;

	this._bigSearchForm = null;
	this._searchIn = null;
	this.SearchFormObj = null;

	this._contactsToMenu = null;

	this._page = 1;
	this._pageSwitcher = null;
	this._sortOrder = SORT_ORDER_DESC;
	this._sortField = SORT_FIELD_EMAIL;
	this.sSearchGroupId = '';
	this._lookFor = '';
	this._lookFirstChar = '';
	this.sContactForEditId = '';

	this._contactsController = null;
	this._contactsTable = null;
	this.oSelection = new CSelection(FillSelectedContactsHandler);
	
	this._minListHeight = 150;//counted variable, depends on (contacts + groups) count on page
	this._listWidthPercent = 40;

	this._toolBar = null;
	this._lowToolBar = null;
	this._contactsCount = null;

	this._cardMinWidth = null;
	
	var obj = this;
	this._newContactObj = new CEditContactScreenPart(obj);
	this._viewContactObj = new CViewContactScreenPart();
	this._newGroupObj = new CEditGroupScreenPart(obj);
	this._importContactsObj = new CImportContactsScreenPart();
	this._selectedContactsObj = new CSelectedContactsScreenPart(obj);

	this._addContactsCount = 0;
	this._addGroupName = '';
	
	this._emptyCard = true;
}

CContactsScreen.prototype = {
	placeData: function(data)
	{
		switch (data.type){
			case TYPE_CONTACTS:
				if (this.HistoryArgs.Entity == PART_CONTACTS || null != this.contacts) {
					this.showEmpty();
				}
				this._newContactObj.CheckContactUpdate();
				this.contacts = data;
				if (this._groupsOutOfDate || this._groupsDeleted) {
					GetHandler(TYPE_GROUPS, {}, [], '');
				}
				this.fill();
				this.SearchFormObj.setStringValue(data.lookFor);
				if (!this._groupsDeleted && this.HistoryArgs.Entity == PART_VIEW_GROUP) {
					this.restoreFromHistory(this.HistoryArgs);
				}
				if (this.HistoryArgs.Entity == PART_EDIT_CONTACT) {
					SetHistoryHandler(
						{
							ScreenId: SCREEN_CONTACTS,
							Entity: PART_VIEW_CONTACT,
							sContactId: this.HistoryArgs.sContactId
						}
					);
				}
				if (data.sAddedContactId.length > 0 && this._newContactObj.DefEmail.length > 0) {
					WebMail.DataSource.cache.replaceFromContactFromMessages(data.sAddedContactId, this._newContactObj.DefEmail);
				}
			break;
			case TYPE_CONTACT:
				this.Contact = data;
				if (this.sContactForEditId.length === 0) {
					this._cardTitle.innerHTML = Lang.TitleViewContact;
					this._viewContactObj.UpdateContact(data);
					this.showViewContact();
					var sContactLineId = data.getIdForList();
					this.oSelection.CheckLine(sContactLineId);
				}
				else {
					this._cardTitle.innerHTML = Lang.TitleEditContact;
					this._newContactObj.fill(this.Contact);
					this.showNewContact();
					this.sContactForEditId = '';
				}
			break;
			case TYPE_GROUPS:
				this._newGroupObj.CheckGroupUpdate();
				this.groups = data;
				this._groupsOutOfDate = false;
				this._groupsDeleted = false;
				this._fillGroups();
				this._newContactObj.fillGroups(data);
			break;
			case TYPE_GROUP:
				this.Group = data;
				this.showNewGroup();
				this._cardTitle.innerHTML = Lang.TitleViewGroup;
				this._newGroupObj.fill(data);
			break;
			case TYPE_UPDATE:
				if (data.value == 'group') {
					if (this._addContactsCount > 0) {
						WebMail.DataSource.cache.clearAllContactsGroupsList();
						WebMail.showReport(Lang.ReportContactAddedToGroup + ' "' + this._addGroupName + '".');
						this._addContactsCount = 0;
						this._addGroupName = '';
						
						SetHistoryHandler(
							{
								ScreenId: SCREEN_CONTACTS,
								Entity: PART_CONTACTS,
								page: this._page,
								sortField: this._sortField,
								sortOrder: this._sortOrder,
								SearchIn: this.sSearchGroupId,
								lookFor: this._lookFor,
								lookFirstChar: this._lookFirstChar
							}
						);
					}
				} else if (data.value == 'sync_contacts') {
					WebMail.DataSource.cache.clearAllContactsGroupsList();
					WebMail.showReport(Lang.ReportContactSyncDone);

					SetHistoryHandler({
						ScreenId: SCREEN_CONTACTS,
						Entity: PART_CONTACTS,
						page: this._page,
						sortField: this._sortField,
						sortOrder: this._sortOrder,
						SearchIn: this.sSearchGroupId,
						lookFor: this._lookFor,
						lookFirstChar: this._lookFirstChar
					});
				}
			break;
		}
	},
	
	clickBody: function(ev)
	{
		if (null != this.SearchFormObj) {
			this.SearchFormObj.checkVisibility();
		}
	},

	onKeyDown: function (key, ev)
	{
		switch (key) {
			case Keys.space:
				this._contactsTable.onKeyDown(Keys.down, ev);
				break;
			case Keys.n:
				if (ev.shiftKey || ev.ctrlKey || ev.altKey) return;
				this._mailContactsTo();
				break;
			case Keys.s:
				if (ev.altKey) {
					this.SearchFormObj.focusSmallForm();
				}
				break;
			default:
				this._contactsTable.onKeyDown(key, ev);
				break;
		}
	},

	resizeBody: function()
	{
		if (!Browser.ie || Browser.version >= 7) {
			var listBorderHeight = 1;
			var externalHeight = WebMail.getHeaderHeight() + this._toolBar.getHeight() + this._lowToolBar.offsetHeight;
			var height = GetHeight() - externalHeight;
			if (height < this._minListHeight) {
				height = this._minListHeight;
			}
			var tableHeight = this._contactsTable.getHeight();
			var cardHeight = this._eCardCont.offsetHeight;
			if (height < tableHeight) {
				height = tableHeight;
			}
			if (height < cardHeight) {
				height = cardHeight;
			}
			var letterSearchHeight = 0;
			if (WebMail.Settings.allowFirstCharacterSearch) {
				letterSearchHeight = this._searchByFirstCharPane.offsetHeight;
			}
			this._mainDiv.style.height = height + 'px';
			this._contactsTable.setLinesHeight(height - listBorderHeight - letterSearchHeight);
			this._contactsTable.resize(this._leftDiv.offsetWidth);
		}
		else {
			this._mainDiv.style.width = ((document.documentElement.clientWidth || document.body.clientWidth) < 850) && (!this._emptyCard) ? '850px' : '100%';
			var listWidth = this._leftDiv.offsetWidth;
			this._contactsTable.resize(listWidth);

			var width = GetWidth();
			if (width < 850) width = 850;
			this._eCardCont.style.width = width - listWidth - 4 + 'px';
		}
		this._pageSwitcher.Replace();
	},
	
	clearContactsAndGroups: function ()
	{
		WebMail.DataSource.cache.clearAllContactsGroupsList();
		this.contacts = null;
		this.groups = null;
	},

	show: function(historyArgs)
	{
		this._mainDiv.className = 'wm_contacts';
		this._lowToolBar.className = 'wm_lowtoolbar';
		this._toolBar.show();
		if (null != this.SearchFormObj) {
			this.SearchFormObj.show();
		}
		if (this.groups == null || this._groupsOutOfDate) {
			GetHandler(TYPE_GROUPS, {}, [], '');
		}
		if (null == historyArgs) {
			historyArgs = {Entity: PART_CONTACTS, page: 1, SearchIn: 0, lookFor: '',
				lookFirstChar: this._lookFirstChar, sortField: CH_NAME, sortOrder: SORT_ORDER_DESC};
		}
		this.restoreFromHistory(historyArgs);
		this.resizeBody();
	},

    _checkContacts: function ()
    {
        if (null == this.contacts) {
            var requestArgs = {
                page: this._page,
                sortField: this._sortField,
                sortOrder: this._sortOrder,
                sGroupId: '',
                lookFor: ''
            };
            this._requestContacts(requestArgs);
        }
    },

    _showCurrentContacts: function ()
    {
        var lastPage = this._pageSwitcher.GetLastPage(0, WebMail.Settings.contactsPerPage);
        var page = (lastPage < this._page) ? lastPage : this._page;
        var requestArgs = {
            page: page,
            sortField: this._sortField,
            sortOrder: this._sortOrder,
            sGroupId: this.sSearchGroupId,
            lookFor: this._lookFor,
			lookFirstChar: this._lookFirstChar
        };
        this._requestContacts(requestArgs);
    },

    _showRequestedContacts: function (historyArgs)
    {
        var requestArgs = {
            page: historyArgs.page,
            sortField: !isNaN(historyArgs.sortField) ? historyArgs.sortField : this._sortField,
            sortOrder: !isNaN(historyArgs.sortOrder) ? historyArgs.sortOrder : this._sortOrder,
            sGroupId: historyArgs.SearchIn,
            lookFor: (typeof(historyArgs.lookFor) == 'string') ? historyArgs.lookFor : '',
			lookFirstChar: (typeof(historyArgs.lookFirstChar) == 'string')
				? historyArgs.lookFirstChar
				: this._lookFirstChar,
			searchType: CONTACTS_SEARCH_TYPE_STANDARD
        };
        this._requestContacts(requestArgs);
    },

    _requestContacts: function (requestArgs)
    {
        var contactsGroups = new CContacts(requestArgs.sGroupId, requestArgs.lookFor,
			requestArgs.lookFirstChar);
        var xml = contactsGroups.getInXml();
        GetHandler(TYPE_CONTACTS, requestArgs, [], xml);
    },
	
	restoreFromHistory: function (historyArgs)
	{
		this.HistoryArgs = historyArgs;
		if (historyArgs.Entity != PART_CONTACTS) {
            if (this._pageSwitcher.pagesCount > 0) {
                this._pageSwitcher.show(0);
            }
			this._checkContacts();
        }
		switch (historyArgs.Entity) {
			case PART_CONTACTS:
				if ('undefined' == typeof(historyArgs.page) || 'undefined' == historyArgs.page || null == historyArgs.page) {
					this._showCurrentContacts();
				}
                else {
					this._showRequestedContacts(historyArgs);
				}
			break;
			case PART_NEW_CONTACT:
				this.oSelection.UncheckAll();
				var contact = new CContact();
				if (historyArgs.name) {
					contact.name = historyArgs.name;
				}
				if (historyArgs.email) {
					contact.hEmail = historyArgs.email;
				}
				contact.useFriendlyName = true;
				this._newContactObj.fill(contact);
				this._cardTitle.innerHTML = Lang.TitleNewContact;
				this.showNewContact();
			break;
			case PART_EDIT_CONTACT:
				if (this.Contact.sContactId === historyArgs.sContactId) {
					this._newContactObj.fill(this.Contact);
					this._cardTitle.innerHTML = Lang.TitleEditContact;
					this.showNewContact();
				}
				else {
					this.sContactForEditId = historyArgs.sContactId;
					GetHandler(TYPE_CONTACT, { sContactId: historyArgs.sContactId }, [], '');
				}
			break;
			case PART_VIEW_CONTACT:
				this._contactsController.CurrIsGroup = false;
				this._contactsController.sCurrContactId = historyArgs.sContactId;
				GetHandler(TYPE_CONTACT, { sContactId: historyArgs.sContactId }, [], '');
			break;
			case PART_NEW_GROUP:
				this.oSelection.UncheckAll();
				var group = new CGroup();
				if (null != historyArgs.contacts) group.contacts = historyArgs.contacts;
				this._cardTitle.innerHTML = Lang.TitleNewGroup;
				this.showNewGroup();
				this._newGroupObj.fill(group);
			break;
			case PART_VIEW_GROUP:
				GetHandler(TYPE_GROUP, { sGroupId: historyArgs.sGroupId }, [], '');
			break;
			case PART_IMPORT_CONTACT:
				this.oSelection.UncheckAll();
				this.showImportContacts();
			break;
		}
	},
	
	contactsImported: function ()
	{
		WebMail.DataSource.cache.clearAllContactsGroupsList();
		SetHistoryHandler(
			{
				ScreenId: SCREEN_CONTACTS,
				Entity: PART_CONTACTS,
				page: this._page,
				sortField: this._sortField,
				sortOrder: this._sortOrder,
				SearchIn: this.sSearchGroupId,
				lookFor: this._lookFor,
				lookFirstChar: this._lookFirstChar
			}
		);
	},
	
	showSelectedContacts: function ()
	{
		this._showPartOfScreen('showSelectedContacts');
	},

	showEmpty: function ()
	{
		this._showPartOfScreen('showEmpty');
	},

	showNewContact: function ()
	{
		this._showPartOfScreen('showNewContact');
	},
	
	showViewContact: function ()
	{
		this._showPartOfScreen('showViewContact');
	},
	
	showNewGroup: function ()
	{
		this._showPartOfScreen('showNewGroup');
	},

	showImportContacts: function ()
	{
		this._showPartOfScreen('showImportContacts');
	},

	_showPartOfScreen: function (type)
	{
		if ('showEmpty' == type){
			this._eCardCont.className = 'wm_hide';
			this._emptyCard = true;
		}
		else {
			this._eCardCont.className = 'wm_contacts_view_edit';
			this._emptyCard = false;
		}
		
		this._selectedContactsObj.hide();
		this._newContactObj.hide();
		this._viewContactObj.hide();
		this._newGroupObj.hide();
		this._importContactsObj.hide();

		switch (type) {
			case 'showSelectedContacts':
				this._cardTitle.innerHTML = Lang.TitleSelectedContacts;
				this._selectedContactsObj.show();
				break;
			case 'showNewContact':
				this._newContactObj.show();
				break;
			case 'showViewContact':
				this._viewContactObj.show();
				break;
			case 'showNewGroup':
				this._newGroupObj.show();
				break;
			case 'showImportContacts':
				this._cardTitle.innerHTML = Lang.TitleImportContacts;
				this._importContactsObj.show();
				break;
		}
		
		this.resizeBody();
	},

	hide: function()
	{
		this._mainDiv.className = 'wm_hide';
		this._lowToolBar.className = 'wm_hide';
		this._toolBar.hide();
		if (null != this.SearchFormObj) {
			this.SearchFormObj.hide();
		}
		this._pageSwitcher.hide();
	},
	
	getXmlParams: function ()
	{
		var params = '';
		params += '<param name="page" value="' + this._page + '"/>';
		params += '<param name="sort_field" value="' + this._sortField + '"/>';
		params += '<param name="sort_order" value="' + this._sortOrder + '"/>';
		return params;
	},

	requestSearchResultsByFirstChar: function (lookFor, searchIn, lookFirstChar)
	{
		this.requestSearchResults(lookFor, searchIn, lookFirstChar);
	},
	
	requestSearchResults: function (lookFor, searchIn, lookFirstChar)
	{
		var iPage = this._page
		if (lookFor.length > 0) {
			iPage = 1;
		}
		SetHistoryHandler(
			{
				ScreenId: SCREEN_CONTACTS,
				Entity: PART_CONTACTS,
				page: iPage,
				sortField: this._sortField,
				sortOrder: this._sortOrder,
				SearchIn: searchIn,
				lookFor: lookFor,
				lookFirstChar: lookFirstChar
			}
		);
	},
	
	requestSearchResultsBySubstring: function ()
	{
		var sSearchGroupId = this._searchIn.value;
		if (sSearchGroupId === STR_SEPARATOR + 'empty_string' + STR_SEPARATOR) {
			sSearchGroupId = '';
		}
		this.requestSearchResults(this.SearchFormObj.getStringValue(), sSearchGroupId,
			this._lookFirstChar);
	},

	deleteSelected: function ()
	{
		if (this.oSelection != null) {
			var idArray = this.oSelection.GetCheckedLines().idArray;
			var iCount = idArray.length;
			if (iCount > 0) {
				var contacts = '';
				var groups = '';
				for (var i=0; i<iCount; i++) {
					var params = idArray[i].split(STR_SEPARATOR);
					if (params.length == 4)
						if (params[1] == '0') {
							contacts += '<contact id="' + params[0] + '"/>';
							WebMail.DataSource.cache.removeFromContactFromMessages(params[0]);
							WebMail.DataSource.cache.removeFromContactInGroups(params[0]);
						}
						else {
							groups += '<group id="' + params[0] + '"/>';
							WebMail.DataSource.cache.removeFromGroupInContacts(params[0]);
						}
				}
				if (contacts.length != 0 || groups.length != 0) {
					if (groups.length != 0) this._groupsDeleted = true;
					var lastPage = this._pageSwitcher.GetLastPage(iCount);
					if (this._page > lastPage) this._page = lastPage;
					var xml = this.getXmlParams();
					xml += '<contacts>' + contacts + '</contacts>';
					xml += '<groups>' + groups + '</groups>';
					if (confirm(Lang.ConfirmAreYouSure)) {
						WebMail.DataSource.cache.clearAllContactsGroupsList();
						RequestHandler('delete', 'contacts', xml);
					}
				}
			}
			else {
				alert(Lang.AlertNoContactsGroupsSelected);
			}
		}
	},

	addContactsToNewGroup: function ()
	{
		if (null === this.oSelection) {
			return;
		}
		var aContacts = Array();
		var aContactIds = this.oSelection.GetCheckedLines().idArray;
		var iCount = aContactIds.length;
		for (var i = 0; i < iCount; i++) {
			var aParams = aContactIds[i].split(STR_SEPARATOR);
			if (aParams.length === 4 && aParams[1] === '0') {
				aContacts[i] = {sContactId: aParams[0], name: aParams[2], email: aParams[3]};
			}
		}
		if (aContacts.length === 0) {
			alert(Lang.AlertNoContactsSelected);
			return;
		}
		SetHistoryHandler(
			{
				ScreenId: SCREEN_CONTACTS,
				Entity: PART_NEW_GROUP,
				contacts: aContacts
			}
		);
	},

	addContactsToGroup: function (sGroupId, sName)
	{
		if (null === this.oSelection) {
			return;
		}
		var sContacts = '';
		var aContactIds = this.oSelection.GetCheckedLines().idArray;
		var iCount = aContactIds.length;
		var iContactsCount = 0;
		var aContactsForCacheAdding = [];
		for (var i = 0; i < iCount; i++) {
			var params = aContactIds[i].split(STR_SEPARATOR);
			if (params.length === 4 && params[1] === '0') {
				sContacts += '<contact id="' + params[0] + '"/>';
				iContactsCount++;
				aContactsForCacheAdding[i] = {id: params[0], name: params[2], email: params[3]};
			}
		}
		if (sContacts.length === 0) {
			alert(Lang.AlertNoContactsSelected);
			return;
		}
		
		WebMail.DataSource.cache.addGroupToContacts(sGroupId, sName, aContactsForCacheAdding);
		var stringDataKey = WebMail.DataSource.getStringDataKey(TYPE_GROUP, {sGroupId: sGroupId});
		WebMail.DataSource.cache.addContactsToGroup(stringDataKey, aContactsForCacheAdding);

		var sParam = '<param name="id_group" value="' + sGroupId + '"/>';
		sParam += this.getXmlParams();
		var sXml = sParam + '<contacts>' + sContacts + '</contacts>';
		RequestHandler('add', 'contacts', sXml);

		this._addContactsCount = iContactsCount;
		this._addGroupName = sName;
	},
	
	_mailContactsTo: function ()
	{
		MailToHandler(this._getStrForMailContacts());
	},

	newMessageClick: function (ev)
	{
		NewMessageClickHandler(ev, this._getStrForMailContacts());
	},

	_getStrForMailContacts: function ()
	{
		var idArray = [];
		if (null != this.oSelection) {
			idArray = this.oSelection.GetCheckedLines().idArray;
		}
		var iCount = idArray.length;
		var emailArray = [];
		for (var i=0; i<iCount; i++) {
			var params = idArray[i].split(STR_SEPARATOR);
			if (params.length == 4 && params[3].length != 0) {
				emailArray.push(HtmlDecode(params[3]));
			}
		}

		return emailArray.join(', ');
	},
	
	_fillGroups: function ()
	{
		var sel = this._searchIn;
		CleanNode(sel);
		var opt = CreateChild(sel, 'option', [['value', STR_SEPARATOR + 'empty_string' + STR_SEPARATOR]]);
		opt.innerHTML = Lang.AllGroups;
		opt.selected = true;

		var obj = this;
		var menu = this._contactsToMenu;
		CleanNode(menu);
		var groups = this.groups.items;
		var iCount = groups.length;
		var div;
		for (var i = 0; i < iCount; i++) {
			div = CreateChild(menu, 'div');
			div.className = 'wm_menu_item';
			div.onmouseover = function () { this.className='wm_menu_item_over'; };
			div.onmouseout = function () { this.className='wm_menu_item'; };
			div.id = groups[i].sGroupId;
			div.innerHTML = groups[i].name;
			div.onclick = function () { obj.addContactsToGroup(this.id, this.innerHTML); };

			opt = CreateChild(sel, 'option', [['value', groups[i].sGroupId]]);
			opt.innerHTML = groups[i].name;
		}
		div = CreateChild(menu, 'div');
		div.className = 'wm_menu_item_spec';
		div.onmouseover = function () { this.className='wm_menu_item_over_spec'; };
		div.onmouseout = function () { this.className='wm_menu_item_spec'; };
		div.innerHTML = '- ' + Lang.NewGroup + ' -';
		WebMail.langChanger.register('innerHTML', div, 'NewGroup', ' -', '- ');
		div.onclick = function () { obj.addContactsToNewGroup(); };
	},
	
	fill: function ()
	{
		this._sortField = this.contacts.sortField;
		this._sortOrder = this.contacts.sortOrder;
		this.sSearchGroupId = this.contacts.sGroupId;
		this._lookFor = this.contacts.lookFor;
		if (WebMail.Settings.allowFirstCharacterSearch) {
			this._lookFirstChar = this.contacts.lookFirstChar;
			this._buildLettersSearch(this._lookFirstChar);
		}
		
		if (this.contacts.count > 0) {
			this._contactsTable.useSort();
			this._contactsTable.setSort(this._sortField, this._sortOrder);
			this._contactsTable.fill(this.contacts.list);
		}
		else {
			this._contactsTable.freeSort();
			this._contactsTable.cleanLines(Lang.InfoNoContactsGroups +
			'<br /><div class="wm_view_message_info">' + Lang.InfoNewContactsGroups + '</div>');
		}
		
		this._page = this.contacts.page;
		var beginHandler = "SetHistoryHandler( { ScreenId: SCREEN_CONTACTS, Entity: PART_CONTACTS, page: ";
		var endHandler = ", sortField: " + this._sortField + ", sortOrder: " + this._sortOrder
			+ ", SearchIn: '" + this.sSearchGroupId + "', lookFirstChar: '" + this._lookFirstChar + "'"
			+ ", lookFor: '" + this._lookFor.replace(/'/g, '\\\'') + "'} );";
		this._pageSwitcher.show(this._page, WebMail.Settings.contactsPerPage, this.contacts.count,
			beginHandler, endHandler);
		this._pageSwitcher.Replace();

		this._setContactsCount(this.contacts.contactsCount);
		this.resizeBody();
	},
	
	fillSelectedContacts: function (contactsArray, sCurrContactId, currIsGroup)
	{
		var contCount = contactsArray.length;
		if (contCount == 0) {
			if (this._selectedContactsObj.shown) {
				this.showEmpty();
			}
			return;
		}
		if (contCount == 1 && currIsGroup == this._contactsController.CurrIsGroup &&
		 sCurrContactId === this._contactsController.sCurrContactId) {
			return;
		}
        else if (contCount > 1) {
			this._contactsController.sCurrContactId = null;
		}	
		this.showSelectedContacts();
		this._selectedContactsObj.fill(contactsArray);
	},
	
	buildAdvancedSearchForm: function()
	{
		var obj = this;
		this._bigSearchForm = CreateChild(document.body, 'div');
		this._bigSearchForm.className = 'wm_hide';
		var frm = CreateChild(this._bigSearchForm, 'form');
		frm.onsubmit = function () { return false; };
		var tbl = CreateChild(frm, 'table');
		var tr = tbl.insertRow(0);
		var td = tr.insertCell(0);
		td.className = 'wm_search_title';
		td.innerHTML = Lang.LookFor;
		WebMail.langChanger.register('innerHTML', td, 'LookFor', '');
		td = tr.insertCell(1);
		td.className = 'wm_search_value';
		var lookForBigInp = CreateChild(td, 'input', [['type', 'text'], ['maxlength', '255']]);
		lookForBigInp.className = 'wm_search_input';
		this._toolBar.CreateSearchButton(td, function () {
			obj.requestSearchResultsBySubstring();
		});
		lookForBigInp.onkeypress = function (ev) {
			if (isEnter(ev)) {
				obj.requestSearchResultsBySubstring();
			}
		};
		tr = tbl.insertRow(1);
		td = tr.insertCell(0);
		td.className = 'wm_search_title';
		td.innerHTML = Lang.SearchIn;
		WebMail.langChanger.register('innerHTML', td, 'SearchIn', '');
		td = tr.insertCell(1);
		td.className = 'wm_search_value';
		this._searchIn = CreateChild(td, 'select');
		return lookForBigInp;
	},
	
	_buildToolBar: function(PopupMenus)
	{
		var obj = this;
		var toolBar = this._toolBar;

		toolBar.addItem(TOOLBAR_BACK_TO_LIST, BackToListHandler, true);
		if (WebMail.Settings.allowComposeMessage) {
			toolBar.addItem(TOOLBAR_NEW_MESSAGE, function (ev) { obj.newMessageClick(ev); }, true);
		}
		toolBar.addItem(TOOLBAR_NEW_CONTACT, function () {
			SetHistoryHandler(
				{
					ScreenId: SCREEN_CONTACTS,
					Entity: PART_NEW_CONTACT
				}
			);
		}, true);
		toolBar.addItem(TOOLBAR_NEW_GROUP, function () {
			SetHistoryHandler(
				{
					ScreenId: SCREEN_CONTACTS,
					Entity: PART_NEW_GROUP,
					contacts: null
				}
			);
		}, true);
		this._contactsToMenu = CreateChild(document.body, 'div');
		this._contactsToMenu.className = 'wm_hide';
		toolBar.addMoveItem(TOOLBAR_ADD_CONTACTS_TO, PopupMenus, this._contactsToMenu, true);
		toolBar.addItem(TOOLBAR_DELETE, function () { obj.deleteSelected(); }, true);
		toolBar.addItem(TOOLBAR_IMPORT_CONTACTS, function () {
			SetHistoryHandler(
				{
					ScreenId: SCREEN_CONTACTS,
					Entity: PART_IMPORT_CONTACT
				}
			);
		}, true);

		var lookForBigInp = this.buildAdvancedSearchForm();
		var searchParts = toolBar.addSearchItems();
		this.SearchFormObj = new CSearchForm(this._bigSearchForm, searchParts.SmallForm,
			searchParts.DownButton.eCont, searchParts.UpButton.eCont,
			lookForBigInp, searchParts.lookFor);
		if (null != this._searchIn) {
			this.SearchFormObj.setSearchIn(this._searchIn);
		}
		searchParts.lookFor.onkeypress = function (ev) {
			if (isEnter(ev)) {
				obj.requestSearchResultsBySubstring();
			}
		};
		searchParts.ActionImg.onclick = function () {
			obj.requestSearchResultsBySubstring();
		};

		toolBar.addClearDiv();
		toolBar.hide();
	},

	_setContactsCount: function (count)
	{
		this._contactsCount.innerHTML = count + '&nbsp;' + Lang.ContactsCount;
	},

	_buildLettersSearch: function (highlightChar)
	{
		CleanNode(this._searchByFirstCharPane);
		function CreateLetterClickFunc(obj, firstChar)
		{
			return function () {
				obj.requestSearchResultsByFirstChar(obj._lookFor, obj.sSearchGroupId, firstChar);
			};
		}
		var lettersArray = ['', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K',
			'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
		var ul = CreateChild(this._searchByFirstCharPane, 'ul');
		for (var i = 0; i < lettersArray.length; i++) {
			var letter = lettersArray[i];
			var li = CreateChild(ul, 'li');
			if (highlightChar == letter) {
				var bold = CreateChild(li, 'b');
				bold.innerHTML = (letter == '') ? Lang.SearchByFirstCharAll : letter;
			}
			else {
				var link = CreateChild(li, 'a', [['href', '#']]);
				link.innerHTML = (letter == '') ? Lang.SearchByFirstCharAll : letter;
				link.onclick = CreateLetterClickFunc(this, letter);
			}
		}
		CreateChild(this._searchByFirstCharPane, 'div', [['style', 'clear: both;']]);
	},

	build: function(container, popupMenus)
	{
		this._toolBar = new CToolBar(container);
		this._buildToolBar(popupMenus);
		
		var mainDiv = CreateChild(container, 'div');
		mainDiv.className = 'wm_hide';
		this._mainDiv = mainDiv;
		var leftDiv = CreateChild(mainDiv, 'div');
		leftDiv.className = 'wm_contacts_list';
		this._leftDiv = leftDiv;

		if (WebMail.Settings.allowFirstCharacterSearch) {
			this._searchByFirstCharPane = CreateChild(leftDiv, 'div',
				[['class', 'wm_search_by_first_char_pane']]);
			this._buildLettersSearch('');
		}

		//contacts list
		this._contactsController = new CContactsTableController(this);
		var contactsTable = new CVariableTable(SortContactsHandler, this.oSelection, null, this._contactsController);
		contactsTable.addColumn(CH_CHECK, ContactsHeaders[CH_CHECK]);
		contactsTable.addColumn(CH_GROUP, ContactsHeaders[CH_GROUP]);
		contactsTable.addColumn(CH_NAME, ContactsHeaders[CH_NAME]);
		contactsTable.addColumn(CH_EMAIL, ContactsHeaders[CH_EMAIL]);
		contactsTable.build(leftDiv);
		this._contactsTable = contactsTable;
		
		this._pageSwitcher = new CPageSwitcher(contactsTable.getLines(), false);
		
		//contact's card on the left part of screen
		var eCardCont = CreateChild(mainDiv, 'div', [['class', 'wm_hide']]);
		this._eCardCont = eCardCont;
		
		CreateChild(eCardCont, 'div', [['class', 'wm_contacts_card_line1']]);
		CreateChild(eCardCont, 'div', [['class', 'wm_contacts_card_line2']]);
		CreateChild(eCardCont, 'div', [['class', 'wm_contacts_card_line3']]);
		CreateChild(eCardCont, 'div', [['class', 'wm_contacts_card_line4']]);
		CreateChild(eCardCont, 'div', [['class', 'wm_contacts_card_line5']]);
		
		var divContent = CreateChild(eCardCont, 'div', [['class', 'wm_contacts_card_content']]);
		var tableContent = CreateChild(divContent, 'table', [['style', 'width: 100%;']]);
		var trTitle = tableContent.insertRow(0);
		var tdTitle = trTitle.insertCell(0);
		tdTitle.style.padding = '0 20px 20px 20px';
		trTitle.style.fontSize = 'large';
		this._cardTitle = tdTitle;
		
		var trContent = tableContent.insertRow(1);
		var tdContent = trContent.insertCell(0);
		//----------//
		
		this._selectedContactsObj.build(tdContent);
		this._newContactObj.build(tdContent);
		this._viewContactObj.build(tdContent);
		this._newGroupObj.build(tdContent);
		this._importContactsObj.build(tdContent);
		
		CreateChild(eCardCont, 'div', [['class', 'wm_contacts_card_line5']]);
		CreateChild(eCardCont, 'div', [['class', 'wm_contacts_card_line4']]);
		CreateChild(eCardCont, 'div', [['class', 'wm_contacts_card_line3']]);
		CreateChild(eCardCont, 'div', [['class', 'wm_contacts_card_line2']]);
		CreateChild(eCardCont, 'div', [['class', 'wm_contacts_card_line1']]);
		
		var lowDiv = CreateChild(container, 'div');
		lowDiv.className = 'wm_hide';
		this._lowToolBar = lowDiv;
		this._contactsCount = CreateChild(lowDiv, 'span', [['class', 'wm_lowtoolbar_messages']]);
		this._setContactsCount(0);

		this.isBuilded = true;
	}//build
};

if (typeof window.JSFileLoaded != 'undefined') {
	JSFileLoaded();
}
