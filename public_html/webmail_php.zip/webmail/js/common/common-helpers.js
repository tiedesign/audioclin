/*
 * Classes:
 *  CBrowser()
 *  CInfoContainer(fadeEffect)
 * Objects:
 *  WindowOpener
 *  Validator
 *  Keys
 *  Favicon
 *  XmlHelper
 *  ButtonsBuilder
 *  Cookies
 *  PreFetch
 *  Logger
 */

function CSlideItem(sObjName)
{
	this.obj = document.getElementById(sObjName);
	
	this.bMoving = false;
	this.iEndHeight = 0;
	this.iStartTime = 0;
	this.iTimerID = -1;
	this.sDir = 'hide';
	this.bLogin = false;

	this.startSlide = function (sDir)
	{
		this.bMoving = true;
		this.sDir = sDir;
		if (this.sDir === 'hide') {
			this.iEndHeight = this.obj.offsetHeight;
		}
		else if (this.iEndHeight === 0) {
			this.iEndHeight = parseInt(this.obj.style.height, 10);
			this.obj.style.height = '1px';
			this.obj.style.display = '';
			this.bLogin = true;
		}
		this.iStartTime = (new Date()).getTime();
	};

	this.endSlide = function ()
	{
		this.bMoving = false;
		clearInterval(this.iTimerID);
	};
}

var Slider = {
	iTimerLen: 40,
	iSlideAniLen: 520,
	aItems: [],

	slideIt: function (sObjName, sDir)
	{
		var oItem = this.aItems[sObjName];
		if (oItem == undefined) {
			oItem = new CSlideItem(sObjName);
		}
		if (oItem.bMoving) {
			return;
		}
		oItem.startSlide(sDir);
		oItem.iTimerID = setInterval('Slider.slideTick(\'' + sObjName + '\')', this.iTimerLen);
		this.aItems[sObjName] = oItem;
	},

	_endSlide: function (oItem) {
		oItem.endSlide();
		if (oItem.bLogin) {
			var iEndHeight = oItem.iEndHeight;
			if (oItem.sDir === 'hide') {
				oItem.obj.style.display = 'none';
				oItem.iEndHeight = 0;
			}
			oItem.obj.style.height = iEndHeight + 'px';
			LoginScreen.changeMode();
		}
		else {
			oItem.obj.style.height = '0px';
			var oListScreen = WebMail.getCurrentListScreen();
			oListScreen.endSlideReplyPane(oItem.sDir);
		}
	},

	slideTick: function (sObjName) {
		var oItem = this.aItems[sObjName];
		if (oItem === undefined) {
			return;
		}
		var iElapsed = (new Date()).getTime() - oItem.iStartTime;
		if (iElapsed > this.iSlideAniLen) {
			this._endSlide(oItem);
		}
		else {
			var fProgress = iElapsed / this.iSlideAniLen;
			fProgress = Math.pow(fProgress, 2);
			var iNewHeight = Math.round(fProgress * oItem.iEndHeight);
			if (oItem.sDir === 'hide') {
				iNewHeight = oItem.iEndHeight - iNewHeight;
			}
			oItem.obj.style.height = iNewHeight + 'px';
		}
		if (!oItem.bLogin) {
			var oListScreen = WebMail.getCurrentListScreen();
			oListScreen.resizeScreen(RESIZE_MODE_MSG_HEIGHT);
		}
		this.aItems[sObjName] = oItem;
	}
};

function CBrowser()
{
	this._init = function ()
	{
		var len = this._profiles.length;
		for (var i = 0; i < len; i++) {
			if (this._profiles[i].criterion) {
				this.name = this._profiles[i].id;
				this.version = this._profiles[i].version();
				break;
			}
		}
		this.ie = (this.name == 'ie' && this.version < 9);
		this.ie9 = (this.name == 'ie' && this.version >= 9);
		this.opera = (this.name == 'opera');
		this.mozilla = (this.name == 'mozilla' || this.name == 'firefox' || this.name == 'netscape'
			|| this.name == 'chrome' || this.name == 'safari');
		this.safari = (this.name == 'safari');
		this.chrome = (this.name == 'chrome');
		this.gecko = (this.opera || this.mozilla);
	};

	this._profiles = [
		{
			id: 'opera',
			criterion: window.opera,
			version: function () {
				var start, end, r, start1, start2;
				r = navigator.userAgent;
				start1 = r.indexOf('Opera/');
				start2 = r.indexOf('Opera ');
				if (-1 == start1) {
					start = start2 + 6;
					end = r.length;
				} else {
					start = start1 + 6;
					end = r.indexOf(' ');
				}
				r = parseFloat(r.slice(start, end));
				return r;
			}
		},
		{
			id: 'chrome',
			criterion:
			(
				(navigator.appCodeName.toLowerCase() == 'mozilla') &&
				(navigator.appName.toLowerCase() == 'netscape') &&
				(navigator.product.toLowerCase() == 'gecko') &&
				(navigator.userAgent.toLowerCase().indexOf('chrome') != -1)
			),
			version: function () {
				return parseFloat(navigator.userAgent.split('Chrome/').reverse().join('Chrome/'));
			}
		},
		{
			id: 'safari',
			criterion:
			(
				(navigator.appCodeName.toLowerCase() == 'mozilla') &&
				(navigator.appName.toLowerCase() == 'netscape') &&
				(navigator.product.toLowerCase() == 'gecko') &&
				(navigator.userAgent.toLowerCase().indexOf('safari') != -1)
			),
			version: function () {
				var r = navigator.userAgent;
				return parseFloat(r.split('Version/').reverse().join(' '));
			}
		},
		{
			id: 'firefox',
			criterion:
			(
				(navigator.appCodeName.toLowerCase() == 'mozilla') &&
				(navigator.appName.toLowerCase() == 'netscape') &&
				(navigator.product.toLowerCase() == 'gecko') &&
				((navigator.userAgent.toLowerCase().indexOf('firefox') != -1) ||
				(navigator.userAgent.toLowerCase().indexOf('iceweasel') != -1))
			),
			version: function () {
				var userAgent = navigator.userAgent.toLowerCase();
				if (userAgent.indexOf('firefox/') != -1) {
					return parseFloat(userAgent.split('firefox/').reverse().join('firefox/'));
				}
				if (userAgent.indexOf('iceweasel/') != -1) {
					return parseFloat(userAgent.split('iceweasel/').reverse().join('iceweasel/'));
				}
				return 0;
			}
		},
		{
			id: 'netscape',
			criterion:
			(
				(navigator.appCodeName.toLowerCase() == 'mozilla') &&
				(navigator.appName.toLowerCase() == 'netscape') &&
				(navigator.product.toLowerCase() == 'gecko') &&
				(navigator.userAgent.toLowerCase().indexOf('netscape') != -1)
			),
			version: function () {
				var r = navigator.userAgent.split(' ').reverse().join(' ');
				r = parseFloat(r.slice(r.indexOf('/') + 1, r.indexOf(' ')));
				return r;
			}
		},
		{
			id: 'mozilla',
			criterion:
			(
				(navigator.appCodeName.toLowerCase() == 'mozilla') &&
				(navigator.appName.toLowerCase() == 'netscape') &&
				(navigator.product.toLowerCase() == 'gecko') &&
				(navigator.userAgent.toLowerCase().indexOf('mozilla') != -1)
			),
			version: function () {
				var r = navigator.userAgent;
				return parseFloat(r.split('Firefox/').reverse().join('Firefox/'));
			}
		},
		{
			id: 'ie',
			criterion:
			(
				(navigator.appName.toLowerCase() == 'microsoft internet explorer') &&
				(navigator.appVersion.toLowerCase().indexOf('msie') !== 0) &&
				(navigator.userAgent.toLowerCase().indexOf('msie') !== 0) &&
				(!window.opera)
			),
			version: function () {
				var r = navigator.userAgent.toLowerCase();
				r = parseFloat(r.slice(r.indexOf('msie') + 4, r.indexOf(';', r.indexOf('msie') + 4)));
				return r;
			}
		}
	];

	this._init();
}

function CInfoContainer(fadeEffect)
{
	this._infoMessage = null;
	this._infoObj = null;
	this._infoVisible = true;
	this._infoShown = false;
	this._errorObj = null;
	this._reportObj = null;
	this._cont = null;
	this._build(fadeEffect);
}

CInfoContainer.prototype = {
	resize: function ()
	{
		this._errorObj.resize();
		this._reportObj.resize();
		this._infoObj.resize();
	},

	unvisible: function()
	{
		this._errorObj.unvisible();
		this._errorObj.hide();
		this._reportObj.unvisible();
		this._reportObj.hide();
		this._infoVisible = false;
	},

	visible: function()
	{
		this._errorObj.visible();
		if (!this._errorObj.shown) {
			this._reportObj.visible();
			this._infoVisible = true;
			if (this._infoShown) {
				this._infoObj.show();
				this._infoObj.resize();
			}
		}
	},

	showInfo: function(info)
	{
		this._infoMessage.innerHTML = info;
		if (this._infoVisible) {
			this._infoObj.show();
			this._infoObj.resize();
		}
		this._infoShown = true;
		this.hideReport();
	},

	hideInfo: function()
	{
		this._infoObj.hide();
		this._infoShown = false;
	},

	showError: function(errorDesc)
	{
		this._errorObj.show(errorDesc);
		this._reportObj.unvisible();
		this._infoVisible = false;
	},

	hideError: function()
	{
		this._errorObj.hide();
		this._reportObj.visible();
		if (!this._reportObj.shown) {
			this._infoVisible = true;
			if (this._infoShown) {
				this._infoObj.show();
				this._infoObj.resize();
			}
		}
	},

	showReport: function(report, priorDelay)
	{
		this._reportObj.show(report, priorDelay);
		this.hideInfo();
	},

	hideReport: function()
	{
		this._reportObj.hide();
	},

	_build: function (fadeEffect)
	{
		var tbl = document.getElementById('info_cont');
		this._infoMessage = document.getElementById('info_message');
		this._infoObj = new CInformation(tbl, 'wm_information wm_status_information');

		this._errorObj = new CReport('WebMail.hideError();', 10000, 'wm_information wm_error_information', true);
		this._errorObj.build();

		this._reportObj = new CReport('WebMail.hideReport();', 5000, 'wm_information wm_report_information', false);
		this._reportObj.build();

		if (!Browser.ie) {
			this._errorObj.setFade(fadeEffect);
			this._reportObj.setFade(fadeEffect);
		}
	}
};

var WindowOpener = {
	_iDefaultWidth: 800,
	_iDefaultHeight: 600,
	_iDefaultRatio: 2 / 3,

	setSizeByRatio: function (iRatio)
	{
		this._iDefaultRatio = iRatio;
		this._iDefaultWidth = Math.ceil(GetWidth() * this._iDefaultRatio);
		this._iDefaultHeight = Math.ceil(GetHeight() * this._iDefaultRatio);
	},

	open: function (sUrl, sPopupName, iWidth, iHeight)
	{
		sPopupName = sPopupName.replace(/[\-\/\.]+/g, '');//forbidden characters in the name of the window for ie
		var sParams = 'toolbar=yes,status=no,scrollbars=yes,resizable=yes';
		sParams += this._getSizeParameters(iWidth, iHeight);
		
		var oWin = window.open(sUrl, sPopupName, sParams);
		oWin.focus();
		return oWin;
	},

	_getSizeParameters: function (iWidth, iHeight)
	{
		var iScreenWidth = GetWidth();
		iWidth = iWidth || this._iDefaultWidth;
		if (iWidth >= iScreenWidth) iWidth = Math.ceil(iScreenWidth * this._iDefaultRatio);
		var iLeft = Math.ceil((iScreenWidth - iWidth) / 2);

		var iScreenHeight = GetHeight();
		iHeight = iHeight || this._iDefaultHeight;
		if (iHeight >= iScreenHeight) iHeight = Math.ceil(iScreenHeight * this._iDefaultRatio);
		var iTop = Math.ceil((iScreenHeight - iHeight) / 2);

		return ',width=' + iWidth + ',height=' + iHeight + ',top=' + iTop + ',left=' + iLeft;
	}
};

var Validator = {
    isEmpty: function (strValue)
    {
		return (strValue.replace(/\s+/g, '') == '');
    },
    
    hasEmailForbiddenSymbols: function (strValue)
    {
		return (strValue.match(/[^A-Z0-9\"!#\$%\^\{\}`~&'\+\-=_@\.]/i));
    },
    
    isCorrectEmail: function (strValue)
    {
		return (strValue.match(/^[A-Z0-9\"!#\$%\^\{\}`~&'\+\-=_\.]+@[A-Z0-9\.\-]+$/i));
    },
    
    isCorrectServerName: function (strValue)
    {
		return (!strValue.match(/[^A-Z0-9\.\-\:\/]/i));
    },
    
    isPositiveNumber: function (intValue)
    {
        if (isNaN(intValue) || intValue <= 0 || Math.round(intValue) != intValue) {
            return false;
        }
        return true;
    },
    
    correctNumber: function (value, minValue, maxValue)
    {
        if (isNaN(value) || value <= minValue) {
            return minValue;
        }
        if (maxValue != undefined && value >= maxValue) {
			return maxValue;
		}
        return Math.round(value);
    },
    
    isPort: function (intValue)
    {
		return (this.isPositiveNumber(intValue) && intValue <= 65535);
    },
    
    hasSpecSymbols: function (strValue)
    {
		return (strValue.match(/["\/\\*?<>|:]/));
    },
    
    isCorrectFileName: function (strValue)
    {
        if (!this.hasSpecSymbols(strValue)) {
			return !strValue.match(/^(CON|AUX|COM1|COM2|COM3|COM4|LPT1|LPT2|LPT3|PRN|NUL)$/i);
        }
        return false;
    },
    
    correctWebPage: function (strValue)
    {
        return strValue.replace(/^[\/;<=>\[\\#\?]+/g, '');
    },
    
    hasFileExtention: function (strValue, strExtension)
    {           
		return (strValue.substr(strValue.length - strExtension.length - 1, strExtension.length + 1).toLowerCase() == '.' + strExtension.toLowerCase());
    },

	isCorrectFolderNameValue: function (sFolderName)
    {
		if (VALIDATION_FOLDER_NAME_REGEXP)
		{
			return null !== sFolderName.match(VALIDATION_FOLDER_NAME_REGEXP);
		}
		return true;
    },
	
	isCorrectFolderNameLength: function (sFolderName)
    {
		if (VALIDATION_FOLDER_NAME_LENGTH && 0 < VALIDATION_FOLDER_NAME_LENGTH)
		{
			return VALIDATION_FOLDER_NAME_LENGTH >= sFolderName.length;
		}
		return true;
    }
};

var Keys = 
{
	tab: 9,
	enter: 13,
	shift: 16,
	ctrl: 17,
	space: 32,
	pageUp: 33,
	pageDown: 34,
	end: 35,
	home: 36,
	up: 38,
	down: 40,
	del: 46,
	a: 65,
	c: 67,
	n: 78,
	p: 80,
	r: 82,
	s: 83,
	comma: 188,
	dot: 190,

	getCodeFromEvent: function (ev)
	{
		var key = -1;
		if (window.event) {
			key = window.event.keyCode;
		}
		else if (ev) {
			key = ev.which;
		}
		return key;
	},

	isTab: function (ev)
	{
		var key = Keys.getCodeFromEvent(ev);
		ev = window.event ? window.event : ev;
		if (!ev.ctrlKey && !ev.shiftKey && !ev.altKey && key === Keys.tab) {
			return true;
		}
		return false;
	}
};

var Favicon = {
//public
	change: function(iconURL) {
		this._init();
		clearTimeout(this._loopTimer);
		this._addLink(iconURL);
	},

	animate: function(iconSequence, optionalDelay) {
		this._init();
		this._preloadIcons(iconSequence);
		this.iconSequence = iconSequence;
		this.sequencePause = (optionalDelay) ?  optionalDelay : this._defaultPause;
		Favicon.index = 0;
		Favicon.change(iconSequence[0]);
		this._loopTimer = setInterval(function() {
			Favicon.index = (Favicon.index + 1) % Favicon.iconSequence.length;
			Favicon._addLink(Favicon.iconSequence[Favicon.index], false);
		}, Favicon.sequencePause);
	},
	
//private
	_defaultPause: 2000,
	_loopTimer: null,
	_iconURL: '',
	_initialized: false,
	_docHead: document.getElementsByTagName('head')[0],

	_init: function ()
	{
		if (this._initialized) return;
		this._initialized = true;
	},

	_preloadIcons: function(iconSequence) {
		var dummyImageForPreloading = document.createElement('img');
		for (var i = 0; i < iconSequence.length; i++) {
			dummyImageForPreloading.src = iconSequence[i];
		}
	},

	_addLink: function(iconURL) {
		this._iconURL = iconURL;
		var link = document.createElement('link');
		link.type = 'image/x-icon';
		link.rel = 'shortcut icon';
		link.href = iconURL;
		this._removeLinkIfExists();
		this._docHead.appendChild(link);
	},

	_removeLinkIfExists: function() {
		var links = this._docHead.getElementsByTagName('link');
		for (var i = 0; i < links.length; i++) {
			var link = links[i];
			if (link.type === 'image/x-icon' && link.rel === 'shortcut icon') {
				this._docHead.removeChild(link);
				return; // Assuming only one match at most.
			}
		}
	}
};

var XmlHelper = {
	getBoolAttributeByName: function (node, sName, bDefaultValue)
	{
		var sDefaultValue = (bDefaultValue) ? 'true' : 'false';
		var sAttr = this.getAttributeByName(node, sName, sDefaultValue);
		var bAttr = (sAttr === '1' || sAttr === 'true') ? true : false;
		return bAttr;
	},

	getIntAttributeByName: function (node, sName, iDefaultValue)
	{
		var sDefaultValue = iDefaultValue + '';
		var sAttr = this.getAttributeByName(node, sName, sDefaultValue);
		var iAttr = sAttr - 0;
		return iAttr;
	},

	/*
	 * return string
	 */
	getAttributeByName: function (node, sName, sDefaultValue)
	{
		if (node === null) {
			return sDefaultValue;
		}
		var sAttr = node.getAttribute(sName);
		if (typeof(sAttr) === 'string') return sAttr;
		return sDefaultValue;
	},

	getFirstChildNodeByName: function (node, sName)
	{
		if (node === null) {
			return null;
		}
		var aChilds = node.childNodes;
		for (var i = 0; i < aChilds.length; i++) {
			if (aChilds[i].tagName === sName) {
				return aChilds[i];
			}
		}
		return null;
	},

	getFirstChildValue: function (node, sDefaultValue)
	{
		if (node === null) {
			return sDefaultValue;
		}
		if (node.childNodes.length > 0) {
			return node.childNodes[0].nodeValue;
		}
		return sDefaultValue;
	}
};

var ButtonsBuilder = {
	addStandard: function (container, langField, clickFunc, rightIndent)
	{
		var inp = CreateChild(container, 'input', [['type', 'button'], ['class', 'wm_button'],
			['value', Lang[langField]]]);
		WebMail.langChanger.register('value', inp, langField, '');
		inp.onclick = clickFunc;
		if (rightIndent) {
			var span = CreateChild(container, 'span');
			span.innerHTML = '&nbsp;';
		}
		return inp;
	},
	
	addForQuickReply: function (container, langField, clickFunc)
	{
		var span = CreateChild(container, 'span');
		span.className = 'wm_reply_button wm_control';
		span.onclick = clickFunc;

		var spanCh = CreateChild(span, 'span');
		spanCh.innerHTML = Lang[langField];
		WebMail.langChanger.register('innerHTML', spanCh, langField, '');
		
		return span;
	}
};

var Cookies = {
//public
	create: function (name, value, days) {
		if (days == undefined) days = COOKIE_STORAGE_DAYS;
		var date = new Date();
		date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
		var expires = '; expires=' + date.toGMTString();
		var path = '; path=' + this._getAppPath();
		document.cookie = name + '=' + value + expires + path;
	},

	erase: function (name) {
		this.create(name, '', -1);
	},

	readBool: function (name, defaultValue)
	{
		var strCookie = this._read(name);
		if (strCookie == null) return defaultValue;
		var boolCookie = (strCookie == '1' || strCookie == 'true') ? true : false;
		return boolCookie;
	},

	readInt: function (name, defaultValue) {
		var strCookie = this._read(name);
		if (strCookie == null) return defaultValue;
		var intCookie = parseInt(strCookie);
		if (intCookie) return intCookie;
		return defaultValue;
	},

//private
	_read: function (name) {
		var nameEQ = name + '=';
		var ca = document.cookie.split(';');
		for (var i = 0; i < ca.length; i++) {
			var c = ca[i];
			while (c.charAt(0) == ' ') {
				c = c.substring(1, c.length);
			}
			if (c.indexOf(nameEQ) == 0) {
				return c.substring(nameEQ.length, c.length);
			}
		}
		return null;
	},

	_getAppPath: function ()
	{
		var path = location.pathname;
		var dotIndex = path.lastIndexOf('.');
		var delimIndex = path.lastIndexOf('/');
		if (delimIndex < dotIndex || delimIndex == path.length - 1) {
			path = path.substring(0, delimIndex);
		}
		if (path.length == 0) {
			path = '/';
		}
		else if (path.substr(path.length - 1, 1) != '/') {
			path += '/';
		}
		return path;
	}
};

var PreFetch = {
	bStartedMessagesBodies: false,
	
	_aMsgsBodiesCache: [],
	_iMsgsBodiesCount: 0,
	_iMsgsBodiesLimit: 5,

	initMessagesBodies: function ()
	{
		this._iMsgsBodiesCount = 0;
	},

	hasInCache: function (sCacheKey)
	{
		return (this._aMsgsBodiesCache[sCacheKey] === true);
	},

	enoughMessagesBodies: function (sCacheKey)
	{
		this._iMsgsBodiesCount++;
		if (this._iMsgsBodiesCount > this._iMsgsBodiesLimit) {
			return true;
		}
		this._aMsgsBodiesCache[sCacheKey] = true;
		return false;
	},

	getMessagesBodies: function (oMessagesBodies, oFoldersParam)
	{
		if (!this.bStartedMessagesBodies) {
			this._oMessagesBodies = oMessagesBodies;
			this._oFoldersParam = oFoldersParam;
		}
		this.bStartedMessagesBodies = false;
		if (this._allowMessagesBodies()) {
			var xml = this._oMessagesBodies.getInXml(this._oFoldersParam);
			if (xml.length > 0) {
				WebMail.DataSource.get(TYPE_MESSAGES_BODIES, {}, [], xml);
				this.bStartedMessagesBodies = true;
			}
		}
		if (this.bStartedMessagesBodies === false) {
			this._aMsgsBodiesCache = [];
		}
	},

	_allowMessagesBodies: function ()
	{
		return (window.UsePrefetch
			&& typeof(this._oMessagesBodies) !== 'undefined'
			&& typeof(this._oFoldersParam) !== 'undefined');
	}
};

TextFormatter = {
	htmlToPlain: function (sText)
	{
		return HtmlDecode(sText.replace(/<br *\/{0,1}>/gi, '\n').replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' '));
	},

	plainToHtml: function (sText)
	{
		return HtmlEncode(sText).replace(/\n/g, '<br>').replace(/ /g, '&nbsp;');
	},

	removeAllTags: function (sText)
	{
		return sText.replace(/<[^>]*>/g, '');
	}
};

var Logger = {
//public
	write: function ()
	{
		this._write(arguments, '; ');
	},

	writeLine: function ()
	{
		this._write(arguments, '<br />');
	},

	clear: function ()
	{
		this._init();
		if (!this._initialized) return;
		this._container.innerHTML = '';
	},

//private
	_container: null,
	_initialized: false,
	
	_init: function ()
	{
		if (this._initialized == true) {
			return;
		}
		this._container = CreateChild(document.body, 'div');
		this._container.dir = 'ltr';

		var st = this._container.style;

		st.color = 'black';
		st.border = 'solid 2px black';
		st.background = 'white';
		st.width = '700px';
		st.height = '100px';
		st.bottom = '0px';
		st.right = '0px';
		st.position = 'absolute';
		st.zIndex = '10';
		st.textAlign = 'left';
		st.overflow = 'auto';

		this._initialized = true;
	},

	_write: function (args, toAdd)
	{
		if (!Browser.opera && window.console && console.log) {
			console.log(args);
		}
		else {
			this._init();
			if (!this._initialized) return;
			var msg = '';
			for (var i = 0; i < args.length; i++) {
				msg += args[i];
				if ((i + 1) < args.length) {
					msg += ', ';
				}
			}
			this._container.innerHTML = this._container.innerHTML + msg + toAdd;
		}
	}
};

if (typeof window.JSFileLoaded != 'undefined') {
	JSFileLoaded();
}
