<?php

	defined('WM_ROOTPATH') || define('WM_ROOTPATH', (dirname(__FILE__).'/../'));

	define('FUNAMBOL_STATUS_NEW',		'N');
	define('FUNAMBOL_STATUS_UPDATED',	'U');
	define('FUNAMBOL_STATUS_DELETED',	'D');

	define('FUNAMBOL_USER_PREFIX',		'wm_');
