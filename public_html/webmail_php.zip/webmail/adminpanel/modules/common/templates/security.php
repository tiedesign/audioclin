<tr>
	<td align="left" width="200">
		<span id="txtUserName_label">AdminPanel&nbsp;login</span>
	</td>
	<td>
		<input type="text" class="wm_input" name="txtUserName" id="txtUserName" value="<?php $this->Data->PrintInputValue('txtUserName') ?>" size="30" />
	</td>
</tr>
<tr>
	<td align="left">
		<span id="txtNewPassword_label">New&nbsp;password</span>
	</td>
	<td>
		<input type="password" class="wm_input" name="txtNewPassword" id="txtNewPassword" value="<?php $this->Data->PrintInputValue('txtNewPassword') ?>" size="30" />
	</td>
</tr>
<tr>
	<td align="left">
		<span id="txtConfirmNewPassword_label">Confirm&nbsp;new&nbsp;password</span>
	</td>
	<td>
		<input type="password" class="wm_input" name="txtConfirmNewPassword" id="txtConfirmNewPassword" value="<?php $this->Data->PrintInputValue('txtConfirmNewPassword') ?>" size="30" />
	</td>
</tr>