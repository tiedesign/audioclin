<?php

/*
 * AfterLogic WebMail Pro PHP by AfterLogic Corp. <support@afterlogic.com>
 *
 * Copyright (C) 2002-2011  AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in COPYING
 * 
 */

	$_rtl = (isset($_GET['rtl']) && $_GET['rtl'] == '1') ? ' dir="rtl"' : '';
	
	@header('Content-type: text/html; charset=utf-8');
	
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html <?php echo $_rtl; ?>>
<head>
	<style> .misspel { background: url(skins/redline.gif) repeat-x bottom; display: inline; } </style>
	<script>
		var z = 0;
		for (var i = 0; i < 10000; i++) {
			z = z + i * 89 / 52 - i * 56 / 78;
		}

		function onLoad()
		{
			try {
				parent.EditAreaLoadHandler();
			}
			catch (er) {}
		}
	</script>
</head>
<body onload="onLoad();">
</body>
</html>