<?php
	$dataPath = 'data';
?>