<?php

define('APP_SESSION_NAME', 'PHPWEBMAILSESSID');

define('APP_SESSION_ACCOUNT_ID', 'id_account');
define('APP_SESSION_USER_ID', 'AUserId');
define('APP_SESSION_LANG', 'session_lang');

define('APP_DUMMYPASSWORD', '*******');

define('APP_MESSAGE_LIST_FILTER_NONE', 0);
define('APP_MESSAGE_LIST_FILTER_UNSEEN', 1);
define('APP_MESSAGE_LIST_FILTER_WITH_ATTACHMENTS', 2);

defined('INI_DIR') || define('INI_DIR', CApi::DataPath());
defined('APP_DEFAULT_OUTPUT_CHARSET') || define('APP_DEFAULT_OUTPUT_CHARSET', CApi::GetConf('webmail.default-out-charset', 'utf-8'));
