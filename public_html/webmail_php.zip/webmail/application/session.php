<?php

	CSession::Start(APP_SESSION_NAME);
