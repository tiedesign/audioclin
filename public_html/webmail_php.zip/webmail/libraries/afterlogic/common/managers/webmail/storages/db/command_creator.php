<?php

/**
 * AfterLogic Api by AfterLogic Corp. <support@afterlogic.com>
 *
 * Copyright (C) 2002-2011  AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in LICENSE.txt
 *
 * @package WebMail
 */

/**
 * @package WebMail
 */
class CApiWebmailCommandCreator extends api_CommandCreator
{
	
}

/**
 * @package WebMail
 */
class CApiWebmailCommandCreatorMySQL extends CApiWebmailCommandCreator
{
}
