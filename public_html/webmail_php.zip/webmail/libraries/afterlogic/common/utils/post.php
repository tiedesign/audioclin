<?php

/**
 * AfterLogic Api by AfterLogic Corp. <support@afterlogic.com>
 *
 * Copyright (C) 2002-2011  AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in LICENSE.txt
 *
 * @package Api
 */

/**
 * @package Api
 */
class CPost
{
	/**
	 * @var bool
	 */
	static $bIsMagicQuotesOn = false;

	private function __construct() {}
	
	/**
	 * @param string $sKey
	 * @return bool
	 */
	static public function Has($sKey)
	{
		return (isset($_POST[$sKey]));
	}
	
	/**
	 * @param string $sKey
	 * @param mixed $nmDefault = null
	 * @return mixed
	 */
	static public function Get($sKey, $nmDefault = null)
	{
		return (isset($_POST[$sKey])) ? self::_stripSlashesValue($_POST[$sKey]) : $nmDefault;;
	}
	
	/**
	 * @param string $sKey
	 * @return bool
	 */
	static public function GetCheckBox($sKey)
	{
		return ('1' === (string) self::Get($sKey, '0'));
	}
	
	/**
	 * @param string $sKey
	 * @param mixed $mValue
	 */
	static public function Set($sKey, $mValue)
	{
		$_POST[$sKey] = $mValue;
	}
	
	/**
	 * @param mixed $mValue
	 * @return mixed
	 */
	static private function _stripSlashesValue($mValue)
	{
		if (!self::$bIsMagicQuotesOn)
		{
			return $mValue;
		}

		$sType = gettype($mValue);
		if ($sType === 'string')
		{
			return stripslashes($mValue);
		}
		else if ($sType === 'array')
		{
			$aReturnValue = array();
			$mValueKeys = array_keys($mValue);
			foreach($mValueKeys as $sKey)
			{
				$aReturnValue[$sKey] = self::_stripSlashesValue($mValue[$sKey]);
			}
			return $aReturnValue;
		}
		else
		{
			return $mValue;
		}
	}
}

CPost::$bIsMagicQuotesOn = (bool) ini_get('magic_quotes_gpc');
